using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class DnDController : ControllerBase
{
    [HttpGet("modifiers")]
    public IActionResult GetModifiers()
    {
        // Create an instance of ModifiersData and populate it with sample data
        var modifiersData = new ModifiersData
        {
            Modifiers = new Dictionary<string, Modifier>
            {
                { "strength", new Modifier { Name = "Strength", Abbreviation = "STR", Value = -2 } },
                { "dexterity", new Modifier { Name = "Dexterity", Abbreviation = "DEX", Value = 2 } },
                { "constitution", new Modifier { Name = "Constitution", Abbreviation = "CON", Value = -1 } },
                { "wisdom", new Modifier { Name = "Wisdom", Abbreviation = "WIS", Value = 0 } },
                { "intelligence", new Modifier { Name = "Intelligence", Abbreviation = "INT", Value = 3 } },
                { "charisma", new Modifier { Name = "Charisma", Abbreviation = "CHA", Value = 1 } }
            }
        };

        return Ok(modifiersData);
    }
}
