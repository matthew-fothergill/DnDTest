using System.Collections.Generic;

public class ModifiersData
{
    public Dictionary<string, Modifier> Modifiers { get; set; }
}
