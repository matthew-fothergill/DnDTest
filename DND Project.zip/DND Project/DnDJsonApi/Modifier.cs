public class Modifier
{
    public string Name { get; set; }
    public string Abbreviation { get; set; }
    public int Value { get; set; }
}
