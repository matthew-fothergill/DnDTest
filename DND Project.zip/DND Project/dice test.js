`let diceRoll = 0;
let testno = 0;



do{
    diceRoll = Math.floor(Math.random() * 13);
if (diceRoll < 1){
    diceRoll = 1;}
    console.log(diceRoll);
testno++;
}
while (testno < 50);`

let diceRoll = 0;
let rollNo = 0;
let advantage = false;
let disadvantage = false;
let diceRoll2 = 0;
let diceRollMod = 0;

let modSTR = -1;
let modDEX = 2;
let modCON = 0;
let modWIS = 1;
let modINT = 3;
let modCHA = 2;
let modBASE = 0;

function Roll(diceSize, rollTimes){
    do{
        diceRoll = Math.floor(Math.random() * (diceSize + 1));
        if (diceRoll < 1){diceRoll = 1}
        console.log(diceRoll);
        rollNo++;
    }
    while (rollNo < rollTimes)};

function AdvRoll(diceSize){
        diceRoll = Math.floor(Math.random() * (diceSize + 1));
        diceRoll2 = Math.floor(Math.random() * (diceSize + 1));
        if (diceRoll < 1){diceRoll = 1};
        if (diceRoll2 < 1){diceRoll2 = 1}
        if (diceRoll > diceRoll2){
            console.log(diceRoll, "(",diceRoll,diceRoll2,")");}
            else if (diceRoll2 > diceRoll){
                console.log(diceRoll2, "(",diceRoll,diceRoll2,")")}
                else{
                    console.log(diceRoll, "(Both rolls were the same)")}

                }

function DisAdvRoll(diceSize){
    diceRoll = Math.floor(Math.random() * (diceSize + 1));
    diceRoll2 = Math.floor(Math.random() * (diceSize + 1));
    if (diceRoll < 1){diceRoll = 1};
    if (diceRoll2 < 1){diceRoll2 = 1}
    if (diceRoll < diceRoll2){
        console.log(diceRoll, "(",diceRoll,diceRoll2,")");}
        else if (diceRoll2 < diceRoll){
            console.log(diceRoll2, "(",diceRoll,diceRoll2,")")}
            else{
                console.log(diceRoll, "(Both rolls were the same)")}

            }

function STRroll(diceSize){
    diceRoll = Math.floor(Math.random() * (diceSize + 1));
        if (diceRoll < 1){diceRoll = 1}
        diceRollMod = diceRoll + modSTR;
        console.log(diceRollMod, "(", diceRoll, "+", modSTR, ")");
}

function modRoll(diceSize, modifier){
    if (modifier == "STR")[modBASE = modSTR];
    if (modifier == "DEX")[modBASE = modDEX];
    if (modifier == "CON")[modBASE = modCON];
    if (modifier == "WIS")[modBASE = modWIS];
    if (modifier == "INT")[modBASE = modINT];
    if (modifier == "CHA")[modBASE = modCHA];
    diceRoll = Math.floor(Math.random() * (diceSize + 1));
        if (diceRoll < 1){diceRoll = 1}
        diceRollMod = diceRoll + modBASE;
        console.log(diceRollMod, "(", diceRoll, "+", modBASE, modifier ,")");
}


            `    Roll(20, 10);
` 
modRoll(20, "INT");

    
