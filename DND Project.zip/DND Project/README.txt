final project is in /DnDJasonApi

Misc Coursework.zip has testing and work from throughout the course, apologies for the mess, id keep a lot of a single day's teaching in one file